<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>환율</title>
</head>

<body>
    <div class="exchange-box">
        <div class="dropdown">
            <button class="dropbtn"id="from-button">USA</button>
            <div class="dropdown-content" id="from-currency-list">
                <a href="#">USD</a>
                <a href="#">KRW</a>
                <a href="#">VND</a>
            </div>
        </div>
        <div class="input-area">
            <input type="number" id="from-input" onkeyup="convert()"/>
            <div>달러</div>
        </div>
    </div>
    <h1>=</h1>
    <div class="exchange-box">
        <div class="dropdown">
            <button class="dropbtn"id="to-button">USA</button>
            <div class="dropdown-content" id="to-currency-list">
                <a href="#">USD</a>
                <a href="#">KRW</a>
                <a href="#">VND</a>
            </div>
        </div>
        <div class="input-area">
            <input type="number" id="to-input">
            <div>달러</div>
        </div>
    </div>
        <script src="main.js"></script>
</body>

</html>